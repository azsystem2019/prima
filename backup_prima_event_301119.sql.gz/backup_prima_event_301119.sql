-- MySQL dump 10.17  Distrib 10.3.20-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: prima-event
-- ------------------------------------------------------
-- Server version	10.3.20-MariaDB-1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix_unitaire` double NOT NULL,
  `prix_casse` double NOT NULL,
  `stock_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_23A0E66DCD6110` (`stock_id`),
  CONSTRAINT `FK_23A0E66DCD6110` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'Assiette',400,800,NULL),(2,'Chapiteaux',90000,90000,NULL),(3,'Verre',3000,3000,NULL),(4,'Fourchette',15000,15000,NULL),(5,'vase',50000,50000,NULL),(6,'Couteaux',3000,3000,NULL),(7,'Chaise',15000,15000,NULL),(8,'sous verre',1000,1000,NULL);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caution`
--

DROP TABLE IF EXISTS `caution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caution`
--

LOCK TABLES `caution` WRITE;
/*!40000 ALTER TABLE `caution` DISABLE KEYS */;
INSERT INTO `caution` VALUES (1,'20191110104125',250000),(2,'20191124100334',84000),(3,'20191124103616',100000),(4,'20191124105206',50000),(5,'11111',100000);
/*!40000 ALTER TABLE `caution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_id` int(11) DEFAULT NULL,
  `type_client_id` int(11) DEFAULT NULL,
  `cin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C7440455DCD6110` (`stock_id`),
  KEY `IDX_C7440455AD2D2831` (`type_client_id`),
  CONSTRAINT `FK_C7440455AD2D2831` FOREIGN KEY (`type_client_id`) REFERENCES `type_client` (`id`),
  CONSTRAINT `FK_C7440455DCD6110` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'razafindrakoto','0340000000','dans l\'espace et dans la lune',NULL,3,NULL,NULL),(2,'Carlton','2245685','Anosy',NULL,2,'1221205623','4586611007862'),(3,'Tana Event','0324533000','Ivato',NULL,2,'15526631545222','175120 45861145'),(4,'Sunrise hotel','22 698 53','Ambanidia',NULL,2,'056 65421 3656 466','7596 13165 346 333'),(5,'CBI','0000000','olm kiii',NULL,2,'4621218523332','1488956232145663');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fournisseur`
--

DROP TABLE IF EXISTS `fournisseur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fournisseur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fournisseur`
--

LOCK TABLES `fournisseur` WRITE;
/*!40000 ALTER TABLE `fournisseur` DISABLE KEYS */;
INSERT INTO `fournisseur` VALUES (1,'Autre event','0340000000','ambohipo');
/*!40000 ALTER TABLE `fournisseur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indemnite`
--

DROP TABLE IF EXISTS `indemnite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indemnite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refence` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indemnite`
--

LOCK TABLES `indemnite` WRITE;
/*!40000 ALTER TABLE `indemnite` DISABLE KEYS */;
INSERT INTO `indemnite` VALUES (1,'11111',10000);
/*!40000 ALTER TABLE `indemnite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES ('20191021190318','2019-10-21 19:03:33'),('20191021190455','2019-10-21 19:05:05'),('20191024190518','2019-10-24 19:05:33'),('20191024190811','2019-10-24 19:08:21'),('20191024191057','2019-10-24 19:11:14'),('20191024191214','2019-10-24 19:12:47'),('20191024191608','2019-10-24 19:16:28'),('20191024191910','2019-10-24 19:19:24'),('20191024194653','2019-10-24 19:47:01'),('20191024195027','2019-10-24 19:50:34'),('20191024195916','2019-10-24 19:59:35'),('20191024200238','2019-10-24 20:02:49'),('20191031172321','2019-10-31 17:23:44'),('20191031181108','2019-10-31 18:11:28'),('20191031182858','2019-10-31 18:29:27'),('20191031183332','2019-10-31 18:36:44'),('20191101052248','2019-11-01 05:23:59'),('20191101092649','2019-11-01 09:27:33'),('20191103055711','2019-11-03 05:57:31'),('20191103092057','2019-11-03 09:21:22'),('20191104150847','2019-11-04 15:09:27'),('20191104152640','2019-11-04 15:27:19'),('20191104162617','2019-11-04 16:26:30'),('20191106160226','2019-11-06 16:03:04'),('20191107012841','2019-11-07 01:29:11'),('20191109064253','2019-11-09 06:43:04'),('20191109065612','2019-11-09 06:56:31'),('20191109074507','2019-11-09 07:46:11'),('20191109083729','2019-11-09 08:38:10'),('20191109083958','2019-11-09 08:40:09'),('20191110073040','2019-11-10 07:31:28'),('20191110111217','2019-11-10 11:12:31'),('20191110112321','2019-11-10 11:23:33'),('20191117052329','2019-11-17 05:24:18'),('20191117060328','2019-11-17 06:03:52'),('20191117060615','2019-11-17 06:06:33'),('20191117071502','2019-11-17 07:15:11'),('20191117071933','2019-11-17 07:20:28');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mode`
--

DROP TABLE IF EXISTS `mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mode`
--

LOCK TABLES `mode` WRITE;
/*!40000 ALTER TABLE `mode` DISABLE KEYS */;
INSERT INTO `mode` VALUES (1,'commande'),(2,'effectif'),(3,'annuler');
/*!40000 ALTER TABLE `mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `motif_payement`
--

DROP TABLE IF EXISTS `motif_payement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `motif_payement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `motif` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `motif_payement`
--

LOCK TABLES `motif_payement` WRITE;
/*!40000 ALTER TABLE `motif_payement` DISABLE KEYS */;
INSERT INTO `motif_payement` VALUES (1,'Location'),(2,'Avance'),(3,'Reste'),(4,'Transport'),(5,'Refacturation');
/*!40000 ALTER TABLE `motif_payement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mouvement`
--

DROP TABLE IF EXISTS `mouvement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mouvement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mouvement` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5B51FC3EDCD6110` (`stock_id`),
  CONSTRAINT `FK_5B51FC3EDCD6110` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvement`
--

LOCK TABLES `mouvement` WRITE;
/*!40000 ALTER TABLE `mouvement` DISABLE KEYS */;
INSERT INTO `mouvement` VALUES (1,'sortie',NULL),(2,'ajout',NULL),(3,'retour',NULL),(4,'cassure',NULL),(5,'usure',NULL);
/*!40000 ALTER TABLE `mouvement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paye`
--

DROP TABLE IF EXISTS `paye`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paye` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refstock` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_payement` date NOT NULL,
  `tva` tinyint(1) NOT NULL,
  `payement_id` int(11) DEFAULT NULL,
  `typepayement_id` int(11) DEFAULT NULL,
  `type_payement_id` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `motif_payement_id` int(11) DEFAULT NULL,
  `ref_payement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C04B89FF868C0609` (`payement_id`),
  KEY `IDX_C04B89FFF8C42054` (`typepayement_id`),
  KEY `IDX_C04B89FFCD95D198` (`type_payement_id`),
  KEY `IDX_C04B89FFBC4657A1` (`motif_payement_id`),
  CONSTRAINT `FK_C04B89FF868C0609` FOREIGN KEY (`payement_id`) REFERENCES `payement` (`id`),
  CONSTRAINT `FK_C04B89FFBC4657A1` FOREIGN KEY (`motif_payement_id`) REFERENCES `motif_payement` (`id`),
  CONSTRAINT `FK_C04B89FFCD95D198` FOREIGN KEY (`type_payement_id`) REFERENCES `type_payement` (`id`),
  CONSTRAINT `FK_C04B89FFF8C42054` FOREIGN KEY (`typepayement_id`) REFERENCES `type_payement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paye`
--

LOCK TABLES `paye` WRITE;
/*!40000 ALTER TABLE `paye` DISABLE KEYS */;
INSERT INTO `paye` VALUES (1,'20191031194030','2019-11-01',1,1,2,NULL,150000,NULL,NULL),(2,'20191103090930','2019-11-06',1,1,3,NULL,140000,1,NULL),(3,'20191103090930','2019-11-06',1,1,3,NULL,140000,1,NULL),(4,'20191106162416','2019-11-06',1,1,3,NULL,140000,1,NULL),(5,'20191106162509','2019-11-06',1,1,3,NULL,140000,1,NULL),(6,'20191106162600','2019-11-06',1,1,3,NULL,140000,1,NULL),(7,'20191103090930','2019-11-06',1,1,3,NULL,140000,1,NULL),(8,'20191103090930','2019-11-06',1,1,3,NULL,140000,1,NULL),(9,'20191103090930','2019-11-06',1,1,1,NULL,140000,1,NULL),(10,'20191103090930','2019-11-06',1,1,1,NULL,50000,2,NULL),(11,'20191103090930','2019-11-06',1,1,2,NULL,1000,3,NULL),(12,'20191102164517','2019-11-10',1,1,2,NULL,100000,1,NULL),(13,'20191110071620','2019-11-10',1,1,1,NULL,600000,1,NULL),(14,'20191110071620','2019-11-10',1,1,1,NULL,600000,1,NULL),(15,'20191110071620','2019-11-10',1,1,1,NULL,600000,1,NULL),(16,'20191110100508','2019-11-10',1,1,2,NULL,600000,1,NULL),(17,'20191110100508','2019-11-10',1,1,2,NULL,600000,1,NULL),(18,'20191110104125','2019-11-10',1,1,2,NULL,500000,1,NULL),(19,'20191124100334','2019-11-24',1,1,2,NULL,336000,2,'20191124101938'),(20,'20191124105206','2019-11-24',1,1,NULL,NULL,1740000,NULL,'20191124105554'),(21,'20191124105206','2019-11-24',1,1,3,NULL,1450000,1,'20191124115617'),(22,'20191124105206','2019-11-24',1,1,3,NULL,1450000,1,'20191124115617'),(23,'0','2019-11-24',1,2,2,NULL,4000000,3,'20191124142648');
/*!40000 ALTER TABLE `paye` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payement`
--

DROP TABLE IF EXISTS `payement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paye_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B20A7885D3964A07` (`paye_id`),
  CONSTRAINT `FK_B20A7885D3964A07` FOREIGN KEY (`paye_id`) REFERENCES `paye` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payement`
--

LOCK TABLES `payement` WRITE;
/*!40000 ALTER TABLE `payement` DISABLE KEYS */;
INSERT INTO `payement` VALUES (1,'entrée',NULL),(2,'sortie',NULL);
/*!40000 ALTER TABLE `payement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilege` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `privilege` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_87209A8719EB6921` (`client_id`),
  CONSTRAINT `FK_87209A8719EB6921` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privilege`
--

LOCK TABLES `privilege` WRITE;
/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
INSERT INTO `privilege` VALUES (1,'normale',NULL),(2,'privilegier',NULL);
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remise`
--

DROP TABLE IF EXISTS `remise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taux` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remise`
--

LOCK TABLES `remise` WRITE;
/*!40000 ALTER TABLE `remise` DISABLE KEYS */;
INSERT INTO `remise` VALUES (1,'20191103090930',30),(2,'20191103090930',30),(3,'20191103090930',30),(4,'20191103090930',30),(5,'20191103090930',30),(6,'20191103090930',30),(7,'20191103090930',30),(8,'20191103090930',30),(9,'20191103090930',30),(10,'20191124105206',100000),(11,'20191124105206',10000),(12,'20191124105206',10000),(13,'20191124105206',10000),(14,'20191124105206',10000),(15,'20191124105206',10000),(16,'20191124105206',10000),(17,'20191124105206',10000),(18,'20191124105206',10000),(19,'20191124105206',10000),(20,'20191124105206',10000),(21,'20191124105206',10000),(22,'20191124105206',10000),(23,'20191124105206',10000),(24,'20191124105206',10000),(25,'20191124105206',10000),(26,'20191124105206',10000),(27,'20191124105206',10000),(28,'20191124105206',10000),(29,'20191124105206',10000),(30,'20191124105206',10000),(31,'20191124105206',10000),(32,'20191124105206',10000),(33,'20191124105206',10000),(34,'20191124105206',10000),(35,'20191124105206',10000),(36,'11111',10000000);
/*!40000 ALTER TABLE `remise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retour`
--

DROP TABLE IF EXISTS `retour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT NULL,
  `quantite_sortie` int(11) NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_retour` date NOT NULL,
  `quantite_retourner` int(11) NOT NULL,
  `cassure` int(11) NOT NULL,
  `prix` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ED6FD3217294869C` (`article_id`),
  CONSTRAINT `FK_ED6FD3217294869C` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retour`
--

LOCK TABLES `retour` WRITE;
/*!40000 ALTER TABLE `retour` DISABLE KEYS */;
/*!40000 ALTER TABLE `retour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retour_article`
--

DROP TABLE IF EXISTS `retour_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retour_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) DEFAULT NULL,
  `quantitesortie` int(11) NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_retour` date NOT NULL,
  `quatite_retourner` int(11) NOT NULL,
  `cassure` int(11) NOT NULL,
  `prix` double NOT NULL,
  `reste` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F0632AEA7294869C` (`article_id`),
  CONSTRAINT `FK_F0632AEA7294869C` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retour_article`
--

LOCK TABLES `retour_article` WRITE;
/*!40000 ALTER TABLE `retour_article` DISABLE KEYS */;
INSERT INTO `retour_article` VALUES (1,1,6,'20191110104125','2019-11-10',0,0,0,6);
/*!40000 ALTER TABLE `retour_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retour_client`
--

DROP TABLE IF EXISTS `retour_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retour_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retour_client`
--

LOCK TABLES `retour_client` WRITE;
/*!40000 ALTER TABLE `retour_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `retour_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'STOCK'),(2,'COMMERCIALE'),(3,'CAISSE'),(4,'ADMIN'),(5,'SUPERVISEUR');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sortie_article`
--

DROP TABLE IF EXISTS `sortie_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sortie_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `refernce` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantite_commander` int(11) NOT NULL,
  `quantite_sortie` int(11) NOT NULL,
  `date` date NOT NULL,
  `reste` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C0EA050B7294869C` (`article_id`),
  CONSTRAINT `FK_C0EA050B7294869C` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sortie_article`
--

LOCK TABLES `sortie_article` WRITE;
/*!40000 ALTER TABLE `sortie_article` DISABLE KEYS */;
INSERT INTO `sortie_article` VALUES (1,3,'20191110071620',200,100,'2019-11-10',100),(2,3,'20191110071620',100,60,'2019-11-10',40),(7,3,'20191110071620',40,40,'2019-11-10',0),(8,3,'20191110071620',0,0,'2019-11-10',0),(9,1,'20191110100508',200,200,'2019-11-10',NULL),(10,3,'20191110100508',200,200,'2019-11-10',NULL),(11,4,'20191110104125',120,75,'2019-11-10',45),(12,1,'20191110104125',30,10,'2019-11-10',20),(13,5,'20191110104125',10,6,'2019-11-10',4),(14,4,'20191110104125',45,45,'2019-11-10',0),(15,1,'20191110104125',20,10,'2019-11-10',10),(16,5,'20191110104125',4,0,'2019-11-10',4),(17,4,'20191110104125',0,0,'2019-11-10',0),(18,1,'20191110104125',10,6,'2019-11-10',4),(19,1,'20191110104125',4,0,'2019-11-10',4);
/*!40000 ALTER TABLE `sortie_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantite` int(11) NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_commande` date DEFAULT NULL,
  `date_sortie_prevue` date DEFAULT NULL,
  `date_sortie_effectif` date DEFAULT NULL,
  `date_retour_prevu` date DEFAULT NULL,
  `date_retour_effectif` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `article_id` int(11) DEFAULT NULL,
  `mouvement_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `mode_id` int(11) DEFAULT NULL,
  `user_sortie_id` int(11) DEFAULT NULL,
  `user_retour_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `quantite_louer` int(11) DEFAULT NULL,
  `nb_jour` int(11) DEFAULT NULL,
  `date_de_validation_proformat` date DEFAULT NULL,
  `commentaire` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remise` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4B365660A76ED395` (`user_id`),
  KEY `IDX_4B3656607294869C` (`article_id`),
  KEY `IDX_4B365660ECD1C222` (`mouvement_id`),
  KEY `IDX_4B36566019EB6921` (`client_id`),
  KEY `IDX_4B36566077E5854A` (`mode_id`),
  KEY `IDX_4B365660CC9254B7` (`user_sortie_id`),
  KEY `IDX_4B36566028368EFB` (`user_retour_id`),
  KEY `IDX_4B36566064D218E` (`location_id`),
  CONSTRAINT `FK_4B36566019EB6921` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`),
  CONSTRAINT `FK_4B36566028368EFB` FOREIGN KEY (`user_retour_id`) REFERENCES `utilisateur` (`id`),
  CONSTRAINT `FK_4B36566064D218E` FOREIGN KEY (`location_id`) REFERENCES `fournisseur` (`id`),
  CONSTRAINT `FK_4B3656607294869C` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  CONSTRAINT `FK_4B36566077E5854A` FOREIGN KEY (`mode_id`) REFERENCES `mode` (`id`),
  CONSTRAINT `FK_4B365660A76ED395` FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`id`),
  CONSTRAINT `FK_4B365660CC9254B7` FOREIGN KEY (`user_sortie_id`) REFERENCES `utilisateur` (`id`),
  CONSTRAINT `FK_4B365660ECD1C222` FOREIGN KEY (`mouvement_id`) REFERENCES `mouvement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (2,12,'20191031191436','2019-10-31','2018-01-01','2019-11-01','2018-02-01',NULL,1,1,1,1,3,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,12,'20191031194030','2019-10-31','2014-04-01','2019-11-01','2017-04-04','2019-11-01',1,1,3,1,2,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(4,12,'20191031194030','2019-10-31','2014-04-01','2019-11-01','2017-04-04','2019-11-01',1,1,3,1,2,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(5,12,'20191031194030','2019-10-31','2014-04-01','2019-11-01','2017-04-04','2019-11-01',1,1,3,1,2,1,1,NULL,NULL,NULL,NULL,NULL,NULL),(6,6,'20191102164517','2019-11-02','2019-11-02','2019-11-03','2019-11-05',NULL,1,1,1,1,2,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,24,'20191103064705','2019-11-03',NULL,NULL,NULL,NULL,1,1,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,2,'20191103090930','2019-11-03','2019-11-07','2019-11-17','2019-11-11',NULL,1,2,1,1,3,1,NULL,NULL,NULL,NULL,'2019-11-09',NULL,NULL),(9,60,'20191109072536','2019-11-09','2020-01-01','2019-11-09','2020-01-04',NULL,1,1,1,1,2,1,NULL,NULL,NULL,4,NULL,NULL,NULL),(10,2,'20191109081409','2019-11-09','2019-11-10','2019-11-17','2019-11-15',NULL,1,2,1,1,3,1,NULL,NULL,NULL,5,NULL,NULL,NULL),(11,30,'20191109102021','2019-11-09','2019-11-09','2019-11-17','2019-11-12',NULL,1,1,1,1,3,1,NULL,NULL,NULL,3,NULL,NULL,NULL),(12,600,'20191109102516','2019-11-09',NULL,NULL,NULL,NULL,1,3,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,100,'20191109102636','2019-11-09','2019-11-12','2019-11-24','2019-11-16',NULL,1,3,1,2,2,1,NULL,NULL,NULL,4,NULL,NULL,NULL),(14,200,'20191110071620','2019-11-10','2019-11-11','2019-11-17','2019-11-13',NULL,1,3,1,2,2,1,NULL,NULL,NULL,3,NULL,NULL,NULL),(15,200,'20191110100508','2019-11-10','2019-11-16','2019-11-24','2019-11-20',NULL,1,1,1,2,2,1,NULL,NULL,NULL,4,'2019-11-10',NULL,NULL),(16,200,'20191110100508','2019-11-10','2019-11-16','2019-11-24','2019-11-20',NULL,1,3,1,2,2,1,NULL,NULL,NULL,4,'2019-11-10',NULL,NULL),(17,300,'20191110103731','2019-11-10',NULL,NULL,NULL,NULL,1,4,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,150,'20191110103731','2019-11-10',NULL,NULL,NULL,NULL,1,5,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,120,'20191110103939','2019-11-10','2019-11-18','2019-11-24','2019-11-23',NULL,1,4,1,3,2,1,NULL,NULL,NULL,5,NULL,NULL,NULL),(20,120,'20191110104125','2019-11-10','2019-11-21',NULL,'2019-11-26',NULL,1,4,1,3,1,NULL,NULL,NULL,NULL,5,'2019-11-10',NULL,NULL),(21,30,'20191110104125','2019-11-10','2019-11-21',NULL,'2019-11-26',NULL,1,1,1,3,1,NULL,NULL,NULL,NULL,5,'2019-11-10',NULL,NULL),(22,10,'20191110104125','2019-11-10','2019-11-21',NULL,'2019-11-26',NULL,1,5,1,3,1,NULL,NULL,NULL,NULL,5,'2019-11-10',NULL,NULL),(23,450,'20191124095738','2019-11-24',NULL,NULL,NULL,NULL,1,1,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,600,'20191124095940','2019-11-24',NULL,NULL,NULL,NULL,1,6,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,400,'20191124100118','2019-11-24',NULL,NULL,NULL,NULL,1,6,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,100,'20191124100334','2019-11-24','2019-12-06','2019-11-24','2019-12-11',NULL,1,6,1,4,2,1,NULL,NULL,NULL,5,'2019-11-24',NULL,4000),(27,100,'20191124100334','2019-11-24','2019-12-06','2019-11-24','2019-12-11',NULL,1,1,1,4,2,1,NULL,NULL,NULL,5,'2019-11-24',NULL,NULL),(28,600,'20191124103103','2019-11-24',NULL,NULL,NULL,NULL,1,3,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,65,'20191124103103','2019-11-24',NULL,NULL,NULL,NULL,1,5,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,800,'20191124103250','2019-11-24',NULL,NULL,NULL,NULL,1,7,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,400,'20191124103529','2019-11-24',NULL,NULL,NULL,NULL,1,7,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,200,'20191124103616','2019-11-24','2019-12-08','2019-11-24','2019-12-13',NULL,1,7,1,2,2,1,NULL,NULL,NULL,5,'2019-11-24',NULL,30000),(33,100,'20191124104616','2019-11-24','2019-12-14','2019-11-24','2019-12-18',NULL,1,7,1,4,2,1,NULL,NULL,NULL,4,'2019-11-24',NULL,50000),(34,100,'20191124105206','2019-11-24','2019-11-24','2019-11-24','2019-11-28',NULL,1,7,1,3,2,1,NULL,NULL,NULL,NULL,'2019-11-24',NULL,50000),(35,600,'20191124110011','2019-11-24',NULL,NULL,NULL,NULL,1,8,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,600,'20191124110102','2019-11-24',NULL,NULL,NULL,NULL,1,8,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,400,'20191124110232','2019-11-24','2019-11-24','2019-11-24','2019-11-24',NULL,1,8,1,5,2,1,NULL,NULL,NULL,1,'2019-11-24',NULL,20000),(38,400,'20191124123131','2019-11-24',NULL,NULL,NULL,NULL,1,1,2,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,400,'20191124123752','2019-11-24','2019-11-25',NULL,'2019-11-27',NULL,1,1,1,2,1,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL),(40,10,'20191124124728','2019-11-24','2019-11-24',NULL,'2019-11-27',NULL,1,2,1,1,1,NULL,NULL,NULL,NULL,4,'2019-11-24',NULL,NULL);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taux_refacturation`
--

DROP TABLE IF EXISTS `taux_refacturation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taux_refacturation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taux` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taux_refacturation`
--

LOCK TABLES `taux_refacturation` WRITE;
/*!40000 ALTER TABLE `taux_refacturation` DISABLE KEYS */;
/*!40000 ALTER TABLE `taux_refacturation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transport`
--

DROP TABLE IF EXISTS `transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transport`
--

LOCK TABLES `transport` WRITE;
/*!40000 ALTER TABLE `transport` DISABLE KEYS */;
INSERT INTO `transport` VALUES (1,'20191106161213',20000),(2,'20191106161331',20000),(3,'20191106161342',20000),(4,'20191106161824',20000),(5,'20191106162725',20000),(6,'20191103090930',20000),(7,'11111',10000);
/*!40000 ALTER TABLE `transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tva`
--

DROP TABLE IF EXISTS `tva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tva` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tva`
--

LOCK TABLES `tva` WRITE;
/*!40000 ALTER TABLE `tva` DISABLE KEYS */;
INSERT INTO `tva` VALUES (1,20);
/*!40000 ALTER TABLE `tva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_client`
--

DROP TABLE IF EXISTS `type_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_client`
--

LOCK TABLES `type_client` WRITE;
/*!40000 ALTER TABLE `type_client` DISABLE KEYS */;
INSERT INTO `type_client` VALUES (1,'particulier'),(2,'entreprise'),(3,'Sans facture');
/*!40000 ALTER TABLE `type_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_payement`
--

DROP TABLE IF EXISTS `type_payement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_payement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_payement`
--

LOCK TABLES `type_payement` WRITE;
/*!40000 ALTER TABLE `type_payement` DISABLE KEYS */;
INSERT INTO `type_payement` VALUES (1,'cheque'),(2,'caisse'),(3,'mobile money');
/*!40000 ALTER TABLE `type_payement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','[\"ROLE_SUPER_ADMIN\"]','$argon2i$v=19$m=65536,t=4,p=1$dHh3bldXejV3bEFFZGM0Rw$IRKoS0uUzxmHE+Nl1y+SMVX1wN8d2f/W22bSsBHRF1E'),(2,'qqqqqqqqqq','[\"ROLE_USER\"]','$argon2i$v=19$m=65536,t=4,p=1$M21qaEw3VFhsUzlidXpDSw$RXIhYw6HHjdmGKiZ+urM8QOFiGhIGhYx343JlY/uY6g'),(4,'wwww','[\"ROLE_SUPERVISEUR\"]','$argon2i$v=19$m=65536,t=4,p=1$UzBiOFhCVUI1OS80MXM0Zw$bV7U2OYfNSXPzllwn0mG10s+j1Y7UFHyr4t1hPEYLz0');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1D1C63B3DCD6110` (`stock_id`),
  KEY `IDX_1D1C63B3D60322AC` (`role_id`),
  CONSTRAINT `FK_1D1C63B3D60322AC` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FK_1D1C63B3DCD6110` FOREIGN KEY (`stock_id`) REFERENCES `stock` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES (1,'prima-event','prima-event','prima','event',NULL,NULL),(2,'admin','argoni2','prima','prima',NULL,NULL),(3,'qqqqqqqqqq','argoni2','qqqqqqqqqq','qqqqqqqqqq',NULL,NULL),(5,'wwww','argoni2','wwww','wwww',NULL,5);
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-30 10:42:49
